﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RestSharp;
using Newtonsoft.Json;
using askPetMDReporting.Models;

namespace askPetMDReporting.Controllers
{
    public class JanrainLookup
    {
        public static Report UserFind()
        {
            var client = new RestClient("https://petmd.us.janraincapture.com/entity.find?client_id=b6ggz2hnm8w7eg6pgpwqbs7apvqehdmr&client_secret=e8u4fwqdkfqcgyw3cbhg37dbqzm6axx4");
            var request = new RestRequest(Method.POST);
            request.RequestFormat = DataFormat.Json;
            request.AddParameter("type_name", "user");
            request.AddParameter("filter", "email='danielddickinson@gmail.com'");
            //request.AddUrlSegment("id", 123);
            //request.AddHeader("header", "value");
            var response = client.Execute(request);
            return JsonConvert.DeserializeObject<Report>(response.Content);
        }
    }
}
