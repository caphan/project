﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft;

namespace askPetMDReporting.Models
{
    public class Report
    {
        public int result_count { get; set; }

        public Results[] Results { get; set; }
    }
}
