﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json;

namespace askPetMDReporting.Models
{
    public class Results
    {
        [JsonProperty("familyName")]
        public string LastName { get; set; }

        public string email { get; set; }
    }
}

